# Granite requested poster source assets — v4.0 handoff

- `granite_poster-brief_fyp1-final_draft.md`: original historical poster brief, unchanged.
- `poster-layout-brief.md`: current v4.0 exact band, panel, local-grid and background coordinates in points and 300-ppi pixels. Use this for the current layout; do not mix its geometry with the old brief.
- `poster-layout.json`: unchanged machine-readable v4.0 drawing and live-text coordinates.
- `investigation-flow.svg`, `refund-desk-dataflow.svg`, `vr1-decision.svg`: existing vector diagrams, unchanged.
- `FASTLogo.jpg`: existing university logo source, 433 × 427 px. No verified SVG/vector PDF was found in the repository. The official university homepage also links to a JPG logo. This is a raster original, not a vector conversion.
- `sha256.txt`: source-file integrity hashes.

Source repository: https://github.com/Shahoud867/Final-Year-Project
Branch: poster-ds-figma-v1.1
Prepared: 2026-11-13
